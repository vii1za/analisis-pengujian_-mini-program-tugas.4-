function nyalakanLampu() {
  document.getElementById("lampu").src = "evi1.jpeg";
}

function matikanLampu() {
  document.getElementById("lampu").src = "evi2.jpeg";
}
